from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import pandas as pd


class InspectToolInput(BaseModel):
    file_path: str = Field(..., description="Path to the sales data CSV file.")


class InspectTool(BaseTool):
    name: str = "InspectTool"
    description: str = "Tool to inspect the sales data file and output its schema and a preview of the data."
    args_schema: Type[BaseModel] = InspectToolInput

    def _run(self, file_path: str) -> str:
        # Load the CSV file into a pandas DataFrame for inspection
        df = pd.read_csv(file_path)
        # Preview the first few rows
        preview = df.head().to_string()
        # Get the schema (column names and types)
        schema = df.dtypes.to_dict()

        return f"Preview of data:\n{preview}\n\nSchema:\n{schema}"
