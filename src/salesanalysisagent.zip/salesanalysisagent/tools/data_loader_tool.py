from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
import os
import pandas as pd


class DataLoaderToolInput(BaseModel):
    file_path: str = Field(..., description="Path to the sales data file.")


class DataLoaderTool(BaseTool):
    name: str = "DataLoaderTool"
    description: str = "Tool to load the sales data if it is in CSV format and return a pandas DataFrame."
    args_schema: Type[BaseModel] = DataLoaderToolInput

    def _run(self, file_path: str) -> pd.DataFrame:
        # Check if the file exists and has a .csv extension
        if not os.path.exists(file_path):
            return f"Error: The file at {file_path} does not exist."

        if not file_path.lower().endswith(".csv"):
            return f"Error: The file {file_path} is not a CSV file."

        # Load the CSV file into a pandas DataFrame
        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            return f"Error: Failed to load the CSV file. {str(e)}"

        return df
