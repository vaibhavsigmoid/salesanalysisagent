from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field, ConfigDict
import pandas as pd


class CodeGenToolInput(BaseModel):
    dataframe: pd.DataFrame = Field(
        ..., description="The cleaned and mapped sales data as a pandas DataFrame."
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)


class CodeGenTool(BaseTool):
    name: str = "CodeGenTool"
    description: str = "Tool to generate code (ETL script) based on cleaned sales data."
    args_schema: Type[BaseModel] = CodeGenToolInput

    def _run(self, dataframe: pd.DataFrame) -> str:
        # Here, we generate code for an ETL pipeline that processes the given dataframe
        script = f"""
                    import pandas as pd

                    # Read the data
                    df = pd.read_csv('path_to_sales_data.csv')

                    # Clean the data
                    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
                    df = df.dropna()

                    # Process the data (example)
                    # Add your processing steps here...

                    # Save the processed data
                    df.to_csv('processed_sales_data.csv', index=False)
                """

        return script
