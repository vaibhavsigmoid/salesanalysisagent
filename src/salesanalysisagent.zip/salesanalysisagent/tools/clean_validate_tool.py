from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field, ConfigDict
import pandas as pd


class CleanValidateToolInput(BaseModel):
    dataframe: pd.DataFrame = Field(
        ..., description="The sales data as a pandas DataFrame."
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)


class CleanValidateTool(BaseTool):
    name: str = "CleanValidateTool"
    description: str = "Tool to clean and validate the sales data."
    args_schema: Type[BaseModel] = CleanValidateToolInput

    def _run(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        # Convert the date column to proper date format
        dataframe["Date"] = pd.to_datetime(dataframe["Date"], errors="coerce")

        # Drop rows with missing or invalid data
        cleaned_df = dataframe.dropna()

        # Additional cleaning logic as needed

        return cleaned_df
