from pydantic import BaseModel, Field, ConfigDict
import pandas as pd
from crewai.tools import BaseTool
from typing import Type


class SchemaMappingToolInput(BaseModel):
    df: pd.DataFrame = Field(..., description="The input dataframe to map")

    model_config = ConfigDict(arbitrary_types_allowed=True)


class SchemaMappingTool(BaseTool):
    name: str = "Schema Mapping Tool"
    description: str = (
        "Maps an input dataframe with unknown schema to a standard sales schema."
    )
    args_schema: Type[BaseModel] = SchemaMappingToolInput

    def _run(self, df: pd.DataFrame) -> pd.DataFrame:
        # Example schema mapping logic (this should be dynamic in real usage)
        standard_columns = {
            "sales_date": ["date", "order_date"],
            "product_id": ["item_id", "product_code"],
            "quantity": ["qty", "amount"],
            "price": ["unit_price", "cost"],
        }

        mapped_df = pd.DataFrame()

        for std_col, aliases in standard_columns.items():
            for alias in aliases:
                if alias in df.columns:
                    mapped_df[std_col] = df[alias]
                    break

        return mapped_df
